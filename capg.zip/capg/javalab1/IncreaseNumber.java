package com.capg.javalab1;

public class IncreaseNumber {
	public boolean flag=true;
	
	public boolean checkNumber(int number) {
		int current=number%10;
		number=number/10;
		while(number>0) {
			if(current<number%10) {
				flag=false;
				break;
			}
			current=number%10;
			number=number/10;
		}
		if(flag==true) {
			System.out.println(" in increasing");
		}else {
			System.out.println("not increasinhg");
				
		}
		return flag;
	}
	public static void main(String args[]) {
		IncreaseNumber n=new IncreaseNumber();
	    n.checkNumber(1234);
		
				
		
		}
	
}
