package com.capg.javalab13;

public class LamdaSquare {
	
		public static void main(String[] args) {
			 ex = (x,y)-> Math.pow(x, y);
			int res = ex.power(7, 2);
			System.out.println("power" +res);

	}
	}



