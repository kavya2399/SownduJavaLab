package com.capg.javalab13;


import java.util.Scanner;
import java.util.function.BiFunction;


public class LamdaVerification {

public static void main(String[] args) {
	BiFunction< String, String, Boolean>bf=(user,pass)->user.equals("prisha")&&pass.equals("prisha123");
	@SuppressWarnings("resource")
	Scanner sc=new Scanner(System.in);
	System.out.println("enter user and password");
	boolean b=bf.apply(sc.next(), sc.next());
	System.out.println(b);
	
}
}



