package com.capg.javalab5;

public class Traffic {
	
		public static void main(String args[]){
			String traffic="yellow";
			switch(traffic){
				case "red":
					System.out.println("stop");
					break;
				case "yellow":
					System.out.println("ready");
				    break;
				case "green":
					System.out.println("go");
			}
			System.out.println("program end");
			
			
			}
		}

